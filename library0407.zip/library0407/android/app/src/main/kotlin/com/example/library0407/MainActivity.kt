package com.example.library0407

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
